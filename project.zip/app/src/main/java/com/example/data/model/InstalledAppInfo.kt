package com.example.data.model

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isBrowserOrVideo: Boolean,
    val isSelected: Boolean
)
