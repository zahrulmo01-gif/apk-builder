package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TranslationEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    // Offline & fast cache dictionary for instant video subtitle response without delay
    private val offlineSubtitleMap = mapOf(
        "hello" to "Halo",
        "how are you" to "Bagaimana kabarmu?",
        "what are you doing" to "Apa yang sedang kamu lakukan?",
        "we need to leave right now" to "Kita harus pergi sekarang juga!",
        "don't look back" to "Jangan menoleh ke belakang!",
        "i have a bad feeling about this" to "Perasaanku tidak enak tentang hal ini",
        "stay with me" to "Tetaplah bersamaku",
        "everything is going to be alright" to "Semuanya akan baik-baik saja",
        "what did you just say?" to "Apa yang baru saja kamu katakan?",
        "the signal is coming from outside" to "Sinyalnya datang dari luar",
        "we can't stop here, this is bat country" to "Kita tidak bisa berhenti di sini, ini wilayah berbahaya",
        "are you ready for the next level?" to "Apakah kamu siap untuk tingkat berikutnya?",
        "listen to the sound of the ocean" to "Dengarkan suara deburan ombak lautan",
        "where did everybody go?" to "Ke mana semua orang pergi?",
        "we must find the key before dawn" to "Kita harus menemukan kuncinya sebelum fajar tiba",
        "is anyone there?" to "Apakah ada orang di sana?",
        "trust me, i know what i'm doing" to "Percayalah padaku, aku tahu apa yang kulakukan",
        "warning! engine overheating" to "Peringatan! Mesin mengalami panas berlebih",
        "welcome back to our channel" to "Selamat datang kembali di saluran kami",
        "don't forget to like and subscribe" to "Jangan lupa untuk sukai dan berlangganan",
        "today we are going to explore this hidden realm" to "Hari ini kita akan menjelajahi alam tersembunyi ini",
        "can you hear me clearly?" to "Bisakah kamu mendengarku dengan jelas?",
        "look at the sky, it's starting to glow" to "Lihat ke langit, mulai bercahaya",
        "this is our only chance to escape" to "Ini satu-satunya kesempatan kita untuk melarikan diri",
        "the mission is compromised" to "Misinya telah terbongkar",
        "wait, did you hear that strange noise?" to "Tunggu, apa kamu mendengar suara aneh itu?",
        "hold your ground, soldiers!" to "Pertahankan posisi kalian, prajurit!"
    )

    suspend fun translate(
        text: String,
        sourceLang: String = "English",
        targetLang: String = "Indonesia",
        isAudioMode: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val cleanText = text.trim()
        if (cleanText.isEmpty()) return@withContext ""

        // Check offline direct match for ultra-fast response
        val lower = cleanText.lowercase().replace(Regex("[^a-zA-Z0-9 ]"), "")
        offlineSubtitleMap[lower]?.let { return@withContext it }

        // 1. First attempt fast online translation via Google Translate API
        try {
            val slCode = if (sourceLang.contains("indo", ignoreCase = true)) "id" else "auto"
            val tlCode = if (targetLang.contains("indo", ignoreCase = true)) "id" else "en"
            val encodedQuery = java.net.URLEncoder.encode(cleanText, "UTF-8")
            val gtxUrl = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$slCode&tl=$tlCode&dt=t&q=$encodedQuery"

            val gtxRequest = Request.Builder()
                .url(gtxUrl)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            client.newCall(gtxRequest).execute().use { res ->
                if (res.isSuccessful) {
                    val resBody = res.body?.string()
                    if (!resBody.isNullOrBlank()) {
                        val jsonArr = JSONArray(resBody)
                        val sentencesArr = jsonArr.optJSONArray(0)
                        if (sentencesArr != null && sentencesArr.length() > 0) {
                            val sb = StringBuilder()
                            for (i in 0 until sentencesArr.length()) {
                                val item = sentencesArr.optJSONArray(i)
                                if (item != null && item.length() > 0) {
                                    sb.append(item.optString(0))
                                }
                            }
                            val result = sb.toString().trim()
                            if (result.isNotEmpty()) {
                                return@withContext result
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d("TranslationEngine", "GTX translation error: ${e.message}")
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (!apiKey.isNullOrBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = if (isAudioMode) {
                    "Kamu adalah penerjemah suara dan subtitle video real-time. Terjemahkan dialog ucapan dari $sourceLang berikut ke dalam bahasa $targetLang subtitle video yang santai, alami, singkat, dan tepat: \"$cleanText\". Hanya berikan teks hasil terjemahan saja tanpa tanda kutip atau penjelasan tambahan."
                } else {
                    "Terjemahkan teks subtitle video dari $sourceLang ke bahasa $targetLang subtitle layar yang pas, ringkas, dan sinematik: \"$cleanText\". Hanya berikan kalimat terjemahannya saja tanpa penjelasan."
                }

                val jsonBody = JSONObject().apply {
                    val contentsArray = JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", prompt)
                                })
                            })
                        })
                    }
                    put("contents", contentsArray)
                }

                val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val bodyString = response.body?.string()
                        if (!bodyString.isNullOrEmpty()) {
                            val root = JSONObject(bodyString)
                            val candidates = root.optJSONArray("candidates")
                            if (candidates != null && candidates.length() > 0) {
                                val content = candidates.getJSONObject(0).optJSONObject("content")
                                val parts = content?.optJSONArray("parts")
                                val translated = parts?.getJSONObject(0)?.optString("text")
                                if (!translated.isNullOrBlank()) {
                                    return@withContext translated.trim().trim('"', '\'')
                                }
                            }
                        }
                    } else {
                        Log.w("TranslationEngine", "Gemini API error ${response.code}: ${response.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e("TranslationEngine", "Gemini API call failed: ${e.message}")
            }
        }

        // Smart rule-based subtitle translation fallback
        return@withContext heuristicTranslate(cleanText, sourceLang, targetLang)
    }

    private fun heuristicTranslate(text: String, sourceLang: String, targetLang: String): String {
        // Common subtitle phrase replacements for English -> Indonesian
        var translated = text
        val phrasePairs = listOf(
            "we have to go" to "kita harus pergi",
            "what's going on" to "apa yang sedang terjadi",
            "what is happening" to "apa yang terjadi",
            "let's get out of here" to "ayo keluar dari sini",
            "i don't know" to "aku tidak tahu",
            "i can't believe it" to "aku tidak percaya ini",
            "are you sure" to "kamu yakin?",
            "look at that" to "lihat itu",
            "be careful" to "hati-hati",
            "come here" to "kemari",
            "hurry up" to "cepat",
            "thank you" to "terima kasih",
            "you're welcome" to "sama-sama",
            "excuse me" to "permisi",
            "good morning" to "selamat pagi",
            "good night" to "selamat malam",
            "see you later" to "sampai jumpa lagi",
            "take care" to "jaga dirimu",
            "who are you" to "siapa kamu?",
            "why are you doing this" to "mengapa kamu melakukan ini?",
            "it's too late" to "ini sudah terlambat",
            "i promise you" to "aku berjanji padamu",
            "don't give up" to "jangan menyerah",
            "stay behind me" to "tetap di belakangku",
            "i hear something" to "aku mendengar sesuatu",
            "there is no time" to "tidak ada waktu lagi"
        )

        for ((en, id) in phrasePairs) {
            val regex = Regex("(?i)\\b$en\\b")
            if (regex.containsMatchIn(translated)) {
                translated = regex.replace(translated, id)
            }
        }

        // Common single word substitutions if no sentence match
        if (translated == text) {
            val words = text.split(" ").map { word ->
                val cleanWord = word.lowercase().replace(Regex("[^a-z]"), "")
                when (cleanWord) {
                    "hello" -> "Halo"
                    "yes" -> "Ya"
                    "no" -> "Tidak"
                    "please" -> "Tolong"
                    "help" -> "Tolong"
                    "wait" -> "Tunggu"
                    "stop" -> "Berhenti"
                    "run" -> "Lari"
                    "look" -> "Lihat"
                    "listen" -> "Dengar"
                    "watch" -> "Awas"
                    "danger" -> "Bahaya"
                    "ready" -> "Siap"
                    "go" -> "Jalan"
                    "now" -> "Sekarang"
                    "later" -> "Nanti"
                    "why" -> "Mengapa"
                    "where" -> "Di mana"
                    "how" -> "Bagaimana"
                    "who" -> "Siapa"
                    "what" -> "Apa"
                    "when" -> "Kapan"
                    else -> word
                }
            }
            translated = words.joinToString(" ")
        }

        // Capitalize first letter
        return if (translated.isNotEmpty()) {
            translated.substring(0, 1).uppercase() + translated.substring(1)
        } else {
            text
        }
    }
}
