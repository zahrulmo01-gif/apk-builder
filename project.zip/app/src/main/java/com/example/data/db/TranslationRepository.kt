package com.example.data.db

import kotlinx.coroutines.flow.Flow

class TranslationRepository(private val dao: TranslationDao) {
    val allRecords: Flow<List<TranslationRecord>> = dao.getAllRecords()
    val favoriteRecords: Flow<List<TranslationRecord>> = dao.getFavoriteRecords()

    suspend fun insert(record: TranslationRecord): Long = dao.insert(record)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) {
        dao.updateFavorite(id, !currentStatus)
    }

    suspend fun clearAll() = dao.clearAll()
}
