package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translation_records")
data class TranslationRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sourceText: String,
    val translatedText: String,
    val sourceLang: String = "English",
    val targetLang: String = "Indonesia",
    val mode: String = "SCREEN", // "SCREEN", "AUDIO", "TEXT"
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
