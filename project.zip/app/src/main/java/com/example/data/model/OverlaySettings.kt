package com.example.data.model

data class OverlaySettings(
    val fontSizeSp: Int = 18,
    val textColorHex: String = "#FFEB3B", // Classic yellow subtitle
    val backgroundColorHex: String = "#CC090D16", // 80% opacity dark slate
    val verticalPositionPercent: Float = 0.80f, // Lower section of screen for subtitles
    val showOriginalSubtitle: Boolean = true, // Bilingual subtitle option
    val subtitleGlowOutline: Boolean = true, // High contrast outline
    val boxCornerRadiusDp: Int = 8,
    val autoFadeDelaySeconds: Int = 4,
    val sourceLanguage: String = "English",
    val targetLanguage: String = "Indonesia",
    val isVoiceDetectionActive: Boolean = false,
    val isFloatingServiceActive: Boolean = false,
    val enableForAllApps: Boolean = true, // Universal support: works on ALL apps including browsers, video players, TikTok, etc.
    val targetAppsPackages: Set<String> = emptySet(), // Specific packages when enableForAllApps is false
    val isAutoScanActive: Boolean = true, // Automatically scans screen for new subtitles while video plays
    val scanSubtitleZone: String = "BOTTOM", // "BOTTOM", "MIDDLE", "FULL"
    val isScreenCaptureActive: Boolean = false // MediaProjection state
)
