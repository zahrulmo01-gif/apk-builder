package com.example.data.model

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class OverlaySettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("overlay_settings_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<OverlaySettings> = _settings.asStateFlow()

    private fun loadSettings(): OverlaySettings {
        return OverlaySettings(
            fontSizeSp = prefs.getInt("font_size", 18),
            textColorHex = prefs.getString("text_color", "#FFEB3B") ?: "#FFEB3B",
            backgroundColorHex = prefs.getString("bg_color", "#CC090D16") ?: "#CC090D16",
            verticalPositionPercent = prefs.getFloat("vertical_pos", 0.80f),
            showOriginalSubtitle = prefs.getBoolean("show_original", true),
            subtitleGlowOutline = prefs.getBoolean("glow_outline", true),
            boxCornerRadiusDp = prefs.getInt("corner_radius", 8),
            autoFadeDelaySeconds = prefs.getInt("fade_delay", 4),
            sourceLanguage = prefs.getString("source_lang", "English") ?: "English",
            targetLanguage = prefs.getString("target_lang", "Indonesia") ?: "Indonesia",
            isVoiceDetectionActive = prefs.getBoolean("voice_detection", false),
            isFloatingServiceActive = prefs.getBoolean("floating_active", false),
            enableForAllApps = prefs.getBoolean("enable_all_apps", true),
            targetAppsPackages = prefs.getStringSet("target_apps", emptySet()) ?: emptySet(),
            isAutoScanActive = prefs.getBoolean("auto_scan", true),
            scanSubtitleZone = prefs.getString("scan_zone", "BOTTOM") ?: "BOTTOM",
            isScreenCaptureActive = prefs.getBoolean("screen_capture_active", false)
        )
    }

    fun updateSettings(newSettings: OverlaySettings) {
        prefs.edit().apply {
            putInt("font_size", newSettings.fontSizeSp)
            putString("text_color", newSettings.textColorHex)
            putString("bg_color", newSettings.backgroundColorHex)
            putFloat("vertical_pos", newSettings.verticalPositionPercent)
            putBoolean("show_original", newSettings.showOriginalSubtitle)
            putBoolean("glow_outline", newSettings.subtitleGlowOutline)
            putInt("corner_radius", newSettings.boxCornerRadiusDp)
            putInt("fade_delay", newSettings.autoFadeDelaySeconds)
            putString("source_lang", newSettings.sourceLanguage)
            putString("target_lang", newSettings.targetLanguage)
            putBoolean("voice_detection", newSettings.isVoiceDetectionActive)
            putBoolean("floating_active", newSettings.isFloatingServiceActive)
            putBoolean("enable_all_apps", newSettings.enableForAllApps)
            putStringSet("target_apps", newSettings.targetAppsPackages)
            putBoolean("auto_scan", newSettings.isAutoScanActive)
            putString("scan_zone", newSettings.scanSubtitleZone)
            putBoolean("screen_capture_active", newSettings.isScreenCaptureActive)
            apply()
        }
        _settings.value = newSettings
    }
}
