package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TranslatorViewModel
import com.example.ui.components.SubtitleOverlayPreview

@Composable
fun ScreenTranslatorView(
    viewModel: TranslatorViewModel,
    onRequestScreenCapture: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playbackSec by viewModel.playbackSecond.collectAsState()
    val selectedSceneIdx by viewModel.selectedSceneIndex.collectAsState()
    val originalSub by viewModel.currentOriginalSubtitle.collectAsState()
    val translatedSub by viewModel.currentTranslatedSubtitle.collectAsState()
    val customInput by viewModel.customSubtitleInput.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()

    val currentScene = viewModel.videoScenes[selectedSceneIdx]
    var showPermissionDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header Badge & Status ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Terjemah Layar Real-Time",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Menimpa subtitle video secara langsung di layar",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF0284C7).copy(alpha = 0.15f))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isPlaying) Color(0xFF10B981) else Color(0xFF94A3B8))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPlaying) "DETEKSI AKTIF" else "JEDA",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF38BDF8)
                    )
                }
            }
        }

        // --- Interactive Video Screen Simulator ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("video_simulator_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column {
                // Top Video Info Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = currentScene.title,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Text(
                        text = "${String.format("%02d:%02d", playbackSec / 60, playbackSec % 60)} / ${String.format("%02d:%02d", currentScene.durationSeconds / 60, currentScene.durationSeconds % 60)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8)
                    )
                }

                // Simulated Video Display Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF090D16),
                                    Color(0xFF0F172A),
                                    Color(0xFF1E1B4B)
                                )
                            )
                        )
                ) {
                    // Animated cosmic / cinema particles
                    VideoAtmosphereCanvas(selectedSceneIdx = selectedSceneIdx)

                    // Watermark / Video Header
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "STREAM 1080P HD",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = Color(0xFFFBBF24)
                        )
                    }

                    // Original Subtitle Simulation Indicator (shown behind overlay to illustrate the overlay concept)
                    if (originalSub.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 54.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.4f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Subtitle Asli (Di Bawah Layar): \"$originalSub\"",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }
                    }

                    // *** REAL-TIME TRANSLATED SUBTITLE OVERLAY (KUMPULAN KETIMPAN DI ATAS VIDEO) ***
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 12.dp, vertical = 12.dp)
                    ) {
                        SubtitleOverlayPreview(
                            settings = settings,
                            originalText = originalSub,
                            translatedText = translatedSub,
                            isLiveBadgeVisible = true
                        )
                    }
                }

                // Progress Bar
                LinearProgressIndicator(
                    progress = { (playbackSec.toFloat() / currentScene.durationSeconds.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = Color(0xFF0284C7),
                    trackColor = Color(0xFF1E293B)
                )

                // Video Controls Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.togglePlayPause() },
                            modifier = Modifier.testTag("play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color(0xFF38BDF8)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.selectScene(selectedSceneIdx) }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay,
                                contentDescription = "Restart Scene",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }

                    // Scene selection pills
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        viewModel.videoScenes.forEachIndexed { index, scene ->
                            val isSelected = index == selectedSceneIdx
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) Color(0xFF0284C7) else Color(0xFF1E293B)
                                    )
                                    .clickable { viewModel.selectScene(index) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (index == 0) "Sci-Fi" else if (index == 1) "Anime" else "Keynote",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- System Floating Overlay Controller Card ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0284C7).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Penerjemah Layar di SEMUA Aplikasi",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Bekerja di Browser (Chrome, Brave, dll.), YouTube, TikTok, dan video player",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Switch(
                        checked = settings.isFloatingServiceActive,
                        onCheckedChange = { enable ->
                            val success = viewModel.toggleFloatingOverlay(enable)
                            if (!success) {
                                showPermissionDialog = true
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF0284C7)
                        ),
                        modifier = Modifier.testTag("floating_overlay_switch")
                    )
                }

                // If overlay is enabled, show OCR Screen Capture setup
                if (settings.isFloatingServiceActive) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (settings.isScreenCaptureActive) Color(0xFF064E3B).copy(alpha = 0.4f) else Color(0xFF78350F).copy(alpha = 0.4f))
                            .border(1.dp, if (settings.isScreenCaptureActive) Color(0xFF10B981) else Color(0xFFF59E0B), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (settings.isScreenCaptureActive) "✅ Pindai Layar Real-Time: AKTIF" else "⚠️ Izin Pindai Layar Diperlukan",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (settings.isScreenCaptureActive) Color(0xFF34D399) else Color(0xFFFBBF24)
                                )
                            }
                            Text(
                                text = if (settings.isScreenCaptureActive)
                                    "TransLayar sedang membaca subtitle video di layar dan menerjemahkannya secara otomatis ke Bahasa Indonesia."
                                else
                                    "Ketuk tombol 'Mulai Rekam Layar (OCR)' di bawah agar TransLayar dapat membaca subtitle video di browser atau aplikasi apa pun yang sedang Anda tonton.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onRequestScreenCapture() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (settings.isScreenCaptureActive) Color(0xFF0284C7) else Color(0xFFF59E0B)
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = if (settings.isScreenCaptureActive) "🔄 Sinkronkan Layar" else "⚡ Mulai Rekam Layar (OCR)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }

                                OutlinedButton(
                                    onClick = { viewModel.triggerImmediateScreenScan() },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("🎯 Pindai Sekali", fontSize = 12.sp, color = Color(0xFF38BDF8))
                                }
                            }
                        }
                    }

                    // Instructions banner for watching browser video
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F172A))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "💡 Cara Nonton Video di Browser dengan Subtitle:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF38BDF8)
                            )
                            Text(
                                text = "1. Buka browser (Chrome, Brave, dll.) & putar video berbahasa Inggris.\n2. Tombol mengambang ⚡ akan membaca subtitle video di layar & menerjemahkannya.\n3. Anda dapat menggeser bilah subtitle ke posisi yang diinginkan.",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 16.sp),
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }

        // --- Quick Overlay Customization Toolbar (Atur Tampilan Subtitle Cepat) ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Pengaturan Cepat Tampilan Subtitle",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    TextButton(
                        onClick = { viewModel.selectTab(3) } // Go to Settings tab
                    ) {
                        Text("Semua Pengaturan", color = Color(0xFF38BDF8), fontSize = 12.sp)
                    }
                }

                // Font Size Quick Adjustment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Ukuran Huruf: ${settings.fontSizeSp}sp",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                if (settings.fontSizeSp > 14) {
                                    viewModel.updateOverlaySettings(settings.copy(fontSizeSp = settings.fontSizeSp - 2))
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(height = 34.dp, width = 48.dp)
                        ) {
                            Text("A-", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                if (settings.fontSizeSp < 28) {
                                    viewModel.updateOverlaySettings(settings.copy(fontSizeSp = settings.fontSizeSp + 2))
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(height = 34.dp, width = 48.dp)
                        ) {
                            Text("A+", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Subtitle Color Chips
                Column {
                    Text(
                        text = "Warna Teks Subtitle:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val colorPresets = listOf(
                            "#FFEB3B" to "Kuning Subtitle",
                            "#FFFFFF" to "Putih",
                            "#38BDF8" to "Cyan",
                            "#4ADE80" to "Hijau",
                            "#FB923C" to "Oranye"
                        )

                        colorPresets.forEach { (hex, name) ->
                            val isSelected = settings.textColorHex.equals(hex, ignoreCase = true)
                            val col = Color(android.graphics.Color.parseColor(hex))
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) Color.White else Color.Black.copy(alpha = 0.4f),
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        viewModel.updateOverlaySettings(settings.copy(textColorHex = hex))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = name,
                                        tint = if (hex == "#FFFFFF" || hex == "#FFEB3B") Color.Black else Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Bilingual toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Mode Dwibahasa (Bilingual)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Tampilkan teks Inggris asli di atas terjemahan",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.showOriginalSubtitle,
                        onCheckedChange = { show ->
                            viewModel.updateOverlaySettings(settings.copy(showOriginalSubtitle = show))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF0284C7)
                        )
                    )
                }
            }
        }

        // --- Custom Subtitle Tester Input ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Coba Terjemahkan & Timpa Teks Sendiri",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Ketikkan dialog film dalam bahasa Inggris untuk melihat hasil terjemahan langsung menimpa di layar simulator.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = customInput,
                    onValueChange = { viewModel.setCustomSubtitleInput(it) },
                    placeholder = { Text("Contoh: We have to escape before dawn...", fontSize = 13.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_subtitle_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0284C7),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = { viewModel.translateCustomSubtitle() },
                            modifier = Modifier.testTag("apply_custom_subtitle_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Terapkan ke Layar",
                                tint = Color(0xFF38BDF8)
                            )
                        }
                    }
                )

                // Quick test suggestions
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val samplePhrases = listOf(
                        "Where did everybody go?",
                        "Don't give up now!",
                        "I have a bad feeling..."
                    )
                    samplePhrases.forEach { phrase ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setCustomSubtitleInput(phrase)
                                    viewModel.translateCustomSubtitle()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = phrase,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    // Permission Dialog for Overlay Window
    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = {
                Text(text = "Izin Menampilkan di Atas Aplikasi Lain")
            },
            text = {
                Text(
                    text = "Untuk menimpa subtitle secara real-time di atas YouTube, Netflix, atau pemutar video lainnya, TransLayar membutuhkan izin \"Tampilkan di atas aplikasi lain\" (Display over other apps).\n\nSilakan aktifkan izin pada layar pengaturan berikut."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionDialog = false
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text("Buka Pengaturan Izin")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun VideoAtmosphereCanvas(selectedSceneIdx: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "stars")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        when (selectedSceneIdx) {
            0 -> {
                // Sci-Fi Space: glowing stars and nebula
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF38BDF8).copy(alpha = 0.3f * pulse), Color.Transparent),
                        center = Offset(size.width * 0.7f, size.height * 0.3f),
                        radius = size.width * 0.4f
                    )
                )
                // Stars
                drawCircle(Color.White.copy(alpha = 0.8f * pulse), radius = 2.dp.toPx(), center = Offset(size.width * 0.2f, size.height * 0.2f))
                drawCircle(Color(0xFFFBBF24).copy(alpha = 0.9f), radius = 3.dp.toPx(), center = Offset(size.width * 0.8f, size.height * 0.5f))
                drawCircle(Color(0xFF38BDF8).copy(alpha = 0.7f), radius = 2.dp.toPx(), center = Offset(size.width * 0.4f, size.height * 0.7f))
            }
            1 -> {
                // Cyberpunk Neon: grid lines
                drawLine(
                    color = Color(0xFFEC4899).copy(alpha = 0.4f * pulse),
                    start = Offset(0f, size.height * 0.6f),
                    end = Offset(size.width, size.height * 0.6f),
                    strokeWidth = 2.dp.toPx()
                )
                drawLine(
                    color = Color(0xFF06B6D4).copy(alpha = 0.4f),
                    start = Offset(size.width * 0.3f, 0f),
                    end = Offset(size.width * 0.3f, size.height),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            else -> {
                // Tech Keynote: subtle spotlight
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF6366F1).copy(alpha = 0.35f * pulse), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.4f),
                        radius = size.width * 0.45f
                    )
                )
            }
        }
    }
}
