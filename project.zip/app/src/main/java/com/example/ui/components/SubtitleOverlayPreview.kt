package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OverlaySettings

@Composable
fun SubtitleOverlayPreview(
    settings: OverlaySettings,
    originalText: String,
    translatedText: String,
    modifier: Modifier = Modifier,
    isLiveBadgeVisible: Boolean = true
) {
    val textColor = try {
        Color(android.graphics.Color.parseColor(settings.textColorHex))
    } catch (e: Exception) {
        Color(0xFFFFEB3B)
    }

    val backgroundColor = try {
        Color(android.graphics.Color.parseColor(settings.backgroundColorHex))
    } catch (e: Exception) {
        Color(0xCC090D16)
    }

    val textShadow = if (settings.subtitleGlowOutline) {
        Shadow(
            color = Color.Black,
            offset = Offset(2f, 2f),
            blurRadius = 6f
        )
    } else null

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(settings.boxCornerRadiusDp.dp))
            .background(backgroundColor)
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.12f),
                shape = RoundedCornerShape(settings.boxCornerRadiusDp.dp)
            )
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (isLiveBadgeVisible) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "TRANSLATAR REAL-TIME OVERLAY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = Color(0xFF38BDF8)
                )
            }
        }

        // Original Subtitle (Bilingual mode)
        if (settings.showOriginalSubtitle && originalText.isNotBlank()) {
            Text(
                text = originalText,
                style = TextStyle(
                    fontSize = (settings.fontSizeSp - 4).coerceAtLeast(11).sp,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    shadow = textShadow
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 2.dp)
            )
        }

        // Translated Subtitle
        Text(
            text = translatedText.ifBlank { "Menunggu dialog video..." },
            style = TextStyle(
                fontSize = settings.fontSizeSp.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                textAlign = TextAlign.Center,
                shadow = textShadow
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun AudioEqualizerWave(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 12
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "anim"
    )

    Row(
        modifier = modifier.height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val factor = if (isActive) {
                ((index % 4) + 1) * 0.25f * animProgress
            } else {
                0.15f
            }
            val heightFraction = factor.coerceIn(0.12f, 1.0f)

            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((36 * heightFraction).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF38BDF8),
                                Color(0xFF10B981)
                            )
                        )
                    )
            )
        }
    }
}
