package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding - Cyber Cyan & Sapphire
val CyanPrimary = Color(0xFF0284C7)
val CyanPrimaryDark = Color(0xFF38BDF8)
val CyanContainer = Color(0xFF0C4A6E)
val OnCyanContainer = Color(0xFFE0F2FE)

// Secondary Branding - Subtitle Gold / Amber
val AmberSecondary = Color(0xFFD97706)
val AmberSecondaryDark = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF78350F)
val OnAmberContainer = Color(0xFFFEF3C7)

// Tertiary Branding - Voice & Audio Emerald
val EmeraldTertiary = Color(0xFF059669)
val EmeraldTertiaryDark = Color(0xFF10B981)

// Dark Slate Theme Canvases
val SlateBackgroundDark = Color(0xFF090D16)
val SlateSurfaceDark = Color(0xFF0F172A)
val SlateSurfaceVariantDark = Color(0xFF1E293B)
val SlateBorderDark = Color(0xFF334155)

// Light Theme Canvases
val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateBorderLight = Color(0xFFE2E8F0)

// Specialized Subtitle Preset Colors
val SubtitleYellow = Color(0xFFFFEB3B)
val SubtitleWhite = Color(0xFFFFFFFF)
val SubtitleCyan = Color(0xFF38BDF8)
val SubtitleGreen = Color(0xFF4ADE80)
val SubtitleOrange = Color(0xFFFB923C)
