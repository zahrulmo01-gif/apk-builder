package com.example.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.TranslationEngine
import com.example.data.db.AppDatabase
import com.example.data.db.TranslationRecord
import com.example.data.db.TranslationRepository
import com.example.data.model.OverlaySettings
import com.example.data.model.OverlaySettingsManager
import com.example.service.AudioVoiceDetector
import com.example.service.FloatingOverlayService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

// Video Simulator Scene Model
data class VideoScene(
    val title: String,
    val genre: String,
    val durationSeconds: Int,
    val subtitleCues: List<SubtitleCue>
)

data class SubtitleCue(
    val startSecond: Int,
    val endSecond: Int,
    val originalText: String,
    val defaultIndonesian: String
)

class TranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TranslationRepository
    val settingsManager = OverlaySettingsManager(application)
    val settings: StateFlow<OverlaySettings> = settingsManager.settings

    private val translationEngine = TranslationEngine()
    val audioVoiceDetector = AudioVoiceDetector(application)

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    // Navigation Tab state
    val _currentTab = MutableStateFlow(0) // 0: Screen Subtitle, 1: Voice Mode, 2: Quick Text, 3: Settings, 4: History
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // --- Screen Video Simulator State ---
    val videoScenes = listOf(
        VideoScene(
            title = "Sci-Fi: Galactic Odyssey",
            genre = "Sci-Fi / Action",
            durationSeconds = 24,
            subtitleCues = listOf(
                SubtitleCue(0, 4, "Warning! The mothership is scanning our perimeter!", "Peringatan! Kapal induk sedang memindai area kita!"),
                SubtitleCue(5, 9, "We need to reroute emergency power right now!", "Kita harus mengalihkan daya darurat sekarang juga!"),
                SubtitleCue(10, 14, "Hold your positions, don't let them breach the shield!", "Pertahankan posisi kalian, jangan biarkan mereka menembus perisai!"),
                SubtitleCue(15, 19, "The hyperspace drive is charged. Prepare to jump!", "Pendorong hiperruang sudah terisi. Bersiap untuk melompat!"),
                SubtitleCue(20, 24, "See you on the other side, commander.", "Sampai jumpa di sisi lain, komandan.")
            )
        ),
        VideoScene(
            title = "Cyberpunk: Neon Chase",
            genre = "Anime / Thriller",
            durationSeconds = 20,
            subtitleCues = listOf(
                SubtitleCue(0, 4, "Don't look back, they are right behind us!", "Jangan menoleh ke belakang, mereka tepat di belakang kita!"),
                SubtitleCue(5, 9, "Activate the optical cloaking system immediately!", "Aktifkan sistem kamuflase optik sekarang juga!"),
                SubtitleCue(10, 14, "I won't let them take the encrypted core.", "Aku tidak akan membiarkan mereka mengambil inti terenkripsi ini."),
                SubtitleCue(15, 20, "Trust me, I have an escape route through the rooftops.", "Percayalah padaku, aku punya jalur pelarian lewat atap gedung.")
            )
        ),
        VideoScene(
            title = "Tech Keynote 2026: AI Era",
            genre = "Presentation / Documentary",
            durationSeconds = 20,
            subtitleCues = listOf(
                SubtitleCue(0, 4, "Welcome everyone to our next-generation keynote.", "Selamat datang semuanya di presentasi generasi berikutnya."),
                SubtitleCue(5, 9, "Today, we are bridging real-time multilingual barriers.", "Hari ini, kita menjembatani batasan multibahasa secara langsung."),
                SubtitleCue(10, 14, "Instant voice and visual translation at your fingertips.", "Terjemahan suara dan visual instan tepat di genggaman Anda."),
                SubtitleCue(15, 20, "Let's dive into the live demonstration.", "Mari kita langsung melihat demonstrasi langsungnya.")
            )
        )
    )

    private val _selectedSceneIndex = MutableStateFlow(0)
    val selectedSceneIndex: StateFlow<Int> = _selectedSceneIndex.asStateFlow()

    private val _playbackSecond = MutableStateFlow(0)
    val playbackSecond: StateFlow<Int> = _playbackSecond.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentOriginalSubtitle = MutableStateFlow("")
    val currentOriginalSubtitle: StateFlow<String> = _currentOriginalSubtitle.asStateFlow()

    private val _currentTranslatedSubtitle = MutableStateFlow("")
    val currentTranslatedSubtitle: StateFlow<String> = _currentTranslatedSubtitle.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private var videoPlaybackJob: Job? = null

    // Custom Subtitle Input test
    private val _customSubtitleInput = MutableStateFlow("")
    val customSubtitleInput: StateFlow<String> = _customSubtitleInput.asStateFlow()

    // --- Voice Mode State ---
    private val _voiceDetectedText = MutableStateFlow("")
    val voiceDetectedText: StateFlow<String> = _voiceDetectedText.asStateFlow()

    private val _voiceTranslatedText = MutableStateFlow("")
    val voiceTranslatedText: StateFlow<String> = _voiceTranslatedText.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    // --- Quick Text Translate State ---
    private val _quickSourceText = MutableStateFlow("")
    val quickSourceText: StateFlow<String> = _quickSourceText.asStateFlow()

    private val _quickTranslatedText = MutableStateFlow("")
    val quickTranslatedText: StateFlow<String> = _quickTranslatedText.asStateFlow()

    private val _quickIsTranslating = MutableStateFlow(false)
    val quickIsTranslating: StateFlow<Boolean> = _quickIsTranslating.asStateFlow()

    // History from Room
    val historyRecords: StateFlow<List<TranslationRecord>>

    // Target Installed Apps List
    private val _installedApps = MutableStateFlow<List<com.example.data.model.InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<com.example.data.model.InstalledAppInfo>> = _installedApps.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = TranslationRepository(db.translationDao())
        historyRecords = repository.allRecords.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        loadInstalledApps()

        // Initialize TTS
        tts = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.forLanguageTag("id-ID")
                isTtsReady = true
            }
        }

        // Setup audio voice detector callback
        audioVoiceDetector.setOnSpeechResultListener { speech ->
            onVoiceSpeechReceived(speech)
        }

        startVideoSimulation()
    }

    fun selectTab(tab: Int) {
        _currentTab.value = tab
    }

    fun selectScene(index: Int) {
        _selectedSceneIndex.value = index
        _playbackSecond.value = 0
        startVideoSimulation()
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
        if (_isPlaying.value) {
            startVideoSimulation()
        } else {
            videoPlaybackJob?.cancel()
        }
    }

    private fun startVideoSimulation() {
        videoPlaybackJob?.cancel()
        videoPlaybackJob = viewModelScope.launch {
            while (_isPlaying.value) {
                val scene = videoScenes[_selectedSceneIndex.value]
                val sec = _playbackSecond.value
                val activeCue = scene.subtitleCues.find { sec in it.startSecond..it.endSecond }

                if (activeCue != null) {
                    if (_currentOriginalSubtitle.value != activeCue.originalText) {
                        _currentOriginalSubtitle.value = activeCue.originalText
                        translateAndApplySubtitle(activeCue.originalText, activeCue.defaultIndonesian)
                    }
                } else {
                    _currentOriginalSubtitle.value = ""
                    _currentTranslatedSubtitle.value = ""
                }

                delay(1000)
                val nextSec = if (sec + 1 >= scene.durationSeconds) 0 else sec + 1
                _playbackSecond.value = nextSec
            }
        }
    }

    private fun translateAndApplySubtitle(original: String, fallbackIndonesian: String) {
        viewModelScope.launch {
            _isTranslating.value = true
            val currentSettings = settings.value
            val result = translationEngine.translate(
                text = original,
                sourceLang = currentSettings.sourceLanguage,
                targetLang = currentSettings.targetLanguage,
                isAudioMode = false
            ).ifBlank { fallbackIndonesian }

            _currentTranslatedSubtitle.value = result
            _isTranslating.value = false

            // Sync with Floating Overlay Service if running
            val intent = Intent(getApplication(), FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_UPDATE_SUBTITLE
                putExtra(FloatingOverlayService.EXTRA_SUBTITLE_TEXT, original)
            }
            try {
                if (settings.value.isFloatingServiceActive) {
                    getApplication<Application>().startService(intent)
                }
            } catch (e: Exception) {}

            // Save to Room DB
            repository.insert(
                TranslationRecord(
                    sourceText = original,
                    translatedText = result,
                    sourceLang = currentSettings.sourceLanguage,
                    targetLang = currentSettings.targetLanguage,
                    mode = "SCREEN"
                )
            )
        }
    }

    fun setCustomSubtitleInput(text: String) {
        _customSubtitleInput.value = text
    }

    fun translateCustomSubtitle() {
        val text = _customSubtitleInput.value.trim()
        if (text.isEmpty()) return

        _currentOriginalSubtitle.value = text
        translateAndApplySubtitle(text, "")
    }

    // --- Voice Mode Logic ---
    fun toggleVoiceListening() {
        val newState = !_isVoiceListening.value
        _isVoiceListening.value = newState
        val current = settings.value
        settingsManager.updateSettings(current.copy(isVoiceDetectionActive = newState))

        if (newState) {
            audioVoiceDetector.startListening("en-US")
        } else {
            audioVoiceDetector.stopListening()
        }
    }

    fun onVoiceSpeechReceived(speech: String) {
        _voiceDetectedText.value = speech
        viewModelScope.launch {
            val currentSettings = settings.value
            val translated = translationEngine.translate(
                text = speech,
                sourceLang = currentSettings.sourceLanguage,
                targetLang = currentSettings.targetLanguage,
                isAudioMode = true
            )
            _voiceTranslatedText.value = translated

            repository.insert(
                TranslationRecord(
                    sourceText = speech,
                    translatedText = translated,
                    sourceLang = currentSettings.sourceLanguage,
                    targetLang = currentSettings.targetLanguage,
                    mode = "AUDIO"
                )
            )
        }
    }

    fun simulateVoiceAudioClip(samplePhrase: String) {
        _voiceDetectedText.value = samplePhrase
        onVoiceSpeechReceived(samplePhrase)
    }

    // --- Quick Text Logic ---
    fun setQuickSourceText(text: String) {
        _quickSourceText.value = text
    }

    fun executeQuickTranslate() {
        val text = _quickSourceText.value.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            _quickIsTranslating.value = true
            val currentSettings = settings.value
            val result = translationEngine.translate(
                text = text,
                sourceLang = currentSettings.sourceLanguage,
                targetLang = currentSettings.targetLanguage,
                isAudioMode = false
            )
            _quickTranslatedText.value = result
            _quickIsTranslating.value = false

            repository.insert(
                TranslationRecord(
                    sourceText = text,
                    translatedText = result,
                    sourceLang = currentSettings.sourceLanguage,
                    targetLang = currentSettings.targetLanguage,
                    mode = "TEXT"
                )
            )
        }
    }

    fun speakText(text: String, isIndonesian: Boolean = true) {
        if (isTtsReady && text.isNotBlank()) {
            tts?.language = if (isIndonesian) Locale.forLanguageTag("id-ID") else Locale.US
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TransLayarTTS")
        }
    }

    // --- Settings Update ---
    fun updateOverlaySettings(newSettings: OverlaySettings) {
        settingsManager.updateSettings(newSettings)
    }

    fun loadInstalledApps() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(intent, 0)
            val currentSelected = settings.value.targetAppsPackages

            val apps = resolveInfos.mapNotNull { ri ->
                val pkg = ri.activityInfo.packageName
                if (pkg == getApplication<Application>().packageName) return@mapNotNull null
                val label = ri.loadLabel(pm).toString()
                val isBrowserOrMedia = pkg.contains("chrome", true) ||
                        pkg.contains("browser", true) ||
                        pkg.contains("opera", true) ||
                        pkg.contains("firefox", true) ||
                        pkg.contains("brave", true) ||
                        pkg.contains("youtube", true) ||
                        pkg.contains("tiktok", true) ||
                        pkg.contains("video", true) ||
                        pkg.contains("player", true) ||
                        pkg.contains("netflix", true) ||
                        pkg.contains("vlc", true)

                com.example.data.model.InstalledAppInfo(
                    packageName = pkg,
                    appName = label,
                    isBrowserOrVideo = isBrowserOrMedia,
                    isSelected = currentSelected.contains(pkg)
                )
            }.sortedWith(compareByDescending<com.example.data.model.InstalledAppInfo> { it.isBrowserOrVideo }.thenBy { it.appName })

            _installedApps.value = apps
        }
    }

    fun setEnableForAllApps(enabled: Boolean) {
        val current = settings.value
        settingsManager.updateSettings(current.copy(enableForAllApps = enabled))
    }

    fun toggleAppSelection(packageName: String) {
        val current = settings.value
        val updatedSet = current.targetAppsPackages.toMutableSet()
        if (updatedSet.contains(packageName)) {
            updatedSet.remove(packageName)
        } else {
            updatedSet.add(packageName)
        }
        settingsManager.updateSettings(current.copy(targetAppsPackages = updatedSet))

        // Update local list
        _installedApps.value = _installedApps.value.map { app ->
            if (app.packageName == packageName) app.copy(isSelected = !app.isSelected) else app
        }
    }

    fun selectAllBrowserAndMediaApps() {
        val mediaPackages = _installedApps.value.filter { it.isBrowserOrVideo }.map { it.packageName }.toSet()
        val current = settings.value
        val newSet = current.targetAppsPackages + mediaPackages
        settingsManager.updateSettings(current.copy(targetAppsPackages = newSet))
        _installedApps.value = _installedApps.value.map { app ->
            if (app.isBrowserOrVideo) app.copy(isSelected = true) else app
        }
    }

    fun setScanSubtitleZone(zone: String) {
        val current = settings.value
        settingsManager.updateSettings(current.copy(scanSubtitleZone = zone))
    }

    fun toggleAutoScan(enabled: Boolean) {
        val current = settings.value
        settingsManager.updateSettings(current.copy(isAutoScanActive = enabled))
    }

    fun onScreenCapturePermissionGranted(resultCode: Int, data: Intent) {
        com.example.service.ScreenOcrCaptureManager.mediaProjectionResultCode = resultCode
        com.example.service.ScreenOcrCaptureManager.mediaProjectionData = data

        val context = getApplication<Application>()
        val intent = Intent(context, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_START_SCREEN_CAPTURE
            putExtra(FloatingOverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingOverlayService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        settingsManager.updateSettings(settings.value.copy(isScreenCaptureActive = true, isFloatingServiceActive = true))
    }

    fun triggerImmediateScreenScan() {
        val context = getApplication<Application>()
        val intent = Intent(context, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_TRIGGER_SCAN
        }
        context.startService(intent)
    }

    fun toggleFloatingOverlay(enable: Boolean): Boolean {
        val context = getApplication<Application>()
        if (enable) {
            if (!Settings.canDrawOverlays(context)) {
                return false // caller should open permission settings
            }
            val intent = Intent(context, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            settingsManager.updateSettings(settings.value.copy(isFloatingServiceActive = true))
            return true
        } else {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_STOP
            }
            context.startService(intent)
            settingsManager.updateSettings(settings.value.copy(isFloatingServiceActive = false))
            return true
        }
    }

    // --- History Actions ---
    fun toggleFavorite(record: TranslationRecord) {
        viewModelScope.launch {
            repository.toggleFavorite(record.id, record.isFavorite)
        }
    }

    fun deleteHistoryRecord(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    override fun onCleared() {
        videoPlaybackJob?.cancel()
        audioVoiceDetector.stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
