package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.api.TranslationEngine
import com.example.data.db.AppDatabase
import com.example.data.db.TranslationRecord
import com.example.data.model.OverlaySettings
import com.example.data.model.OverlaySettingsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var windowManager: WindowManager? = null

    private var subtitleHudView: View? = null
    private var floatingBubbleView: View? = null
    private var floatingMenuPopupView: View? = null

    private lateinit var settingsManager: OverlaySettingsManager
    private val translationEngine = TranslationEngine()
    private var audioVoiceDetector: AudioVoiceDetector? = null
    private var screenOcrManager: ScreenOcrCaptureManager? = null

    companion object {
        const val CHANNEL_ID = "translayar_overlay_channel"
        const val NOTIFICATION_ID = 101
        const val ACTION_STOP = "com.example.translayar.ACTION_STOP"
        const val ACTION_TOGGLE_VOICE = "com.example.translayar.ACTION_TOGGLE_VOICE"
        const val ACTION_UPDATE_SUBTITLE = "com.example.translayar.ACTION_UPDATE_SUBTITLE"
        const val ACTION_START_SCREEN_CAPTURE = "com.example.translayar.ACTION_START_SCREEN_CAPTURE"
        const val ACTION_TRIGGER_SCAN = "com.example.translayar.ACTION_TRIGGER_SCAN"
        const val ACTION_TOGGLE_AUTO_SCAN = "com.example.translayar.ACTION_TOGGLE_AUTO_SCAN"
        const val EXTRA_SUBTITLE_TEXT = "extra_subtitle_text"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settingsManager = OverlaySettingsManager(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()

        screenOcrManager = ScreenOcrCaptureManager(this) { detectedText ->
            processNewSubtitle(detectedText, isVoice = false)
        }

        if (Settings.canDrawOverlays(this)) {
            setupSubtitleHudWindow()
            setupFloatingBubbleWindow()
        }

        observeSettings()

        // Check if cached media projection token is available
        val cachedCode = ScreenOcrCaptureManager.mediaProjectionResultCode
        val cachedData = ScreenOcrCaptureManager.mediaProjectionData
        if (cachedCode != 0 && cachedData != null) {
            initScreenProjection(cachedCode, cachedData)
        }
    }

    private fun startForegroundServiceNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "TransLayar Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Penerjemah Layar dan Suara Video Real-time Berjalan di Semua Aplikasi"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val scanIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_TRIGGER_SCAN },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TransLayar Aktif di Semua Aplikasi")
            .setContentText("Siap menerjemahkan subtitle video di Browser, YouTube & aplikasi lainnya")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_search, "Pindai Sekarang", scanIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan", stopIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun getOverlayLayoutFlag(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    /**
     * 1. Floating Subtitle HUD Window: shows the detected subtitle & translated subtitle.
     */
    private fun setupSubtitleHudWindow() {
        if (subtitleHudView != null) return

        val displayMetrics = resources.displayMetrics
        val currentSettings = settingsManager.settings.value

        val subtitleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayLayoutFlag(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (displayMetrics.heightPixels * currentSettings.verticalPositionPercent).toInt()
        }

        val overlayLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 12, 24, 12)
        }

        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 16, 32, 16)
            tag = "subtitle_card_box"

            val bgShape = GradientDrawable().apply {
                cornerRadius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12f, displayMetrics)
                setColor(Color.parseColor("#E6090D16"))
                setStroke(2, Color.parseColor("#38BDF8"))
            }
            background = bgShape
        }

        val originalTextView = TextView(this).apply {
            tag = "original_subtitle_text"
            text = "Menunggu subtitle video layar..."
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
        }

        val translatedTextView = TextView(this).apply {
            tag = "translated_subtitle_text"
            text = "TransLayar aktif: Ketuk tombol mengambang ⚡ untuk pindai layar"
            setTextColor(Color.parseColor("#FFEB3B"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 2f, 2f, Color.BLACK)
        }

        cardBox.addView(originalTextView)
        cardBox.addView(translatedTextView)
        overlayLayout.addView(cardBox)

        // Make subtitle bar draggable vertically so users can adjust it over any video
        overlayLayout.setOnTouchListener(object : View.OnTouchListener {
            var initialY = 0
            var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialY = subtitleParams.y
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        subtitleParams.y = (initialY + (event.rawY - initialTouchY)).toInt()
                        try {
                            windowManager?.updateViewLayout(overlayLayout, subtitleParams)
                        } catch (e: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val newPercent = (subtitleParams.y.toFloat() / displayMetrics.heightPixels.toFloat()).coerceIn(0.1f, 0.92f)
                        val s = settingsManager.settings.value
                        settingsManager.updateSettings(s.copy(verticalPositionPercent = newPercent))
                        return true
                    }
                }
                return false
            }
        })

        subtitleHudView = overlayLayout
        try {
            windowManager?.addView(subtitleHudView, subtitleParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        applyStyleToOverlay(settingsManager.settings.value)
    }

    /**
     * 2. Draggable Floating Bubble Window: A circular widget at the screen edge.
     * Allows 1-tap "Scan Now", toggling "Auto-Scan", "Voice Mode", or opening app settings.
     */
    private fun setupFloatingBubbleWindow() {
        if (floatingBubbleView != null) return

        val displayMetrics = resources.displayMetrics
        val bubbleSizePx = (54 * displayMetrics.density).toInt()

        val bubbleParams = WindowManager.LayoutParams(
            bubbleSizePx,
            bubbleSizePx,
            getOverlayLayoutFlag(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = displayMetrics.widthPixels - bubbleSizePx - 20
            y = (displayMetrics.heightPixels * 0.45f).toInt()
        }

        val bubbleLayout = FrameLayout(this).apply {
            val bgDrawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0284C7"))
                setStroke(4, Color.parseColor("#38BDF8"))
            }
            background = bgDrawable
            elevation = 16f
        }

        val iconText = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        bubbleLayout.addView(iconText)

        // Make Bubble draggable & handle clicks
        bubbleLayout.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            var isClick = true

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = bubbleParams.x
                        initialY = bubbleParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        bubbleParams.x = initialX + dx
                        bubbleParams.y = initialY + dy
                        try {
                            windowManager?.updateViewLayout(bubbleLayout, bubbleParams)
                        } catch (e: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleFloatingMenuPopup(bubbleParams.x, bubbleParams.y)
                        } else {
                            // Snap to nearest side edge
                            val screenWidth = resources.displayMetrics.widthPixels
                            bubbleParams.x = if (bubbleParams.x < screenWidth / 2) 20 else screenWidth - bubbleSizePx - 20
                            try {
                                windowManager?.updateViewLayout(bubbleLayout, bubbleParams)
                            } catch (e: Exception) {}
                        }
                        return true
                    }
                }
                return false
            }
        })

        floatingBubbleView = bubbleLayout
        try {
            windowManager?.addView(floatingBubbleView, bubbleParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Shows/hides floating menu popup with actions:
     * - Scan Now (⚡)
     * - Auto-Scan Toggle (🔄)
     * - Voice Mode Toggle (🎙️)
     * - Open App Settings (⚙️)
     * - Close (❌)
     */
    private fun toggleFloatingMenuPopup(anchorX: Int, anchorY: Int) {
        if (floatingMenuPopupView != null) {
            dismissFloatingMenuPopup()
            return
        }

        val displayMetrics = resources.displayMetrics
        val menuParams = WindowManager.LayoutParams(
            (240 * displayMetrics.density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayLayoutFlag(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchorX - (180 * displayMetrics.density).toInt()).coerceIn(20, displayMetrics.widthPixels - (260 * displayMetrics.density).toInt())
            y = (anchorY - (50 * displayMetrics.density).toInt()).coerceIn(40, displayMetrics.heightPixels - (280 * displayMetrics.density).toInt())
        }

        val menuLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            val bg = GradientDrawable().apply {
                cornerRadius = 16 * displayMetrics.density
                setColor(Color.parseColor("#F00F172A"))
                setStroke(2, Color.parseColor("#38BDF8"))
            }
            background = bg
        }

        // Title
        val title = TextView(this).apply {
            text = "TransLayar Menu Layar"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 4, 8, 12)
        }
        menuLayout.addView(title)

        // 1. Scan Screen Now Button
        menuLayout.addView(createMenuItem("⚡ Pindai Layar Sekarang", "#38BDF8") {
            dismissFloatingMenuPopup()
            triggerScreenScanNow()
        })

        // 2. Auto-Scan Toggle
        val isAuto = settingsManager.settings.value.isAutoScanActive
        menuLayout.addView(createMenuItem(if (isAuto) "🔄 Auto-Scan: AKTIF" else "🔄 Auto-Scan: NONAKTIF", if (isAuto) "#4ADE80" else "#94A3B8") {
            dismissFloatingMenuPopup()
            val current = settingsManager.settings.value
            val nextState = !current.isAutoScanActive
            settingsManager.updateSettings(current.copy(isAutoScanActive = nextState))
            Toast.makeText(this, if (nextState) "Auto-Scan Real-Time Aktif" else "Auto-Scan Dimatikan", Toast.LENGTH_SHORT).show()
        })

        // 3. Voice Toggle
        val isVoice = settingsManager.settings.value.isVoiceDetectionActive
        menuLayout.addView(createMenuItem(if (isVoice) "🎙️ Audio/Suara: AKTIF" else "🎙️ Audio/Suara: NONAKTIF", if (isVoice) "#FB923C" else "#94A3B8") {
            dismissFloatingMenuPopup()
            val current = settingsManager.settings.value
            val nextVoice = !current.isVoiceDetectionActive
            settingsManager.updateSettings(current.copy(isVoiceDetectionActive = nextVoice))
            Toast.makeText(this, if (nextVoice) "Deteksi Suara Video Aktif" else "Deteksi Suara Dimatikan", Toast.LENGTH_SHORT).show()
        })

        // 4. Open Settings
        menuLayout.addView(createMenuItem("⚙️ Pengaturan & Target Aplikasi", "#E2E8F0") {
            dismissFloatingMenuPopup()
            val appIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(appIntent)
        })

        // 5. Close Overlay
        menuLayout.addView(createMenuItem("❌ Sembunyikan TransLayar", "#F87171") {
            dismissFloatingMenuPopup()
            settingsManager.updateSettings(settingsManager.settings.value.copy(isFloatingServiceActive = false))
            stopSelf()
        })

        floatingMenuPopupView = menuLayout
        try {
            windowManager?.addView(floatingMenuPopupView, menuParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun dismissFloatingMenuPopup() {
        floatingMenuPopupView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {}
        }
        floatingMenuPopupView = null
    }

    private fun createMenuItem(label: String, colorHex: String, onClick: () -> Unit): TextView {
        val displayMetrics = resources.displayMetrics
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor(colorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(12, 14, 12, 14)
            val itemBg = GradientDrawable().apply {
                cornerRadius = 8 * displayMetrics.density
                setColor(Color.parseColor("#1E293B"))
            }
            background = itemBg
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 4, 0, 6)
            layoutParams = lp
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
    }

    private fun triggerScreenScanNow() {
        if (screenOcrManager?.isReady() == true) {
            Toast.makeText(this, "Memindai subtitle video di layar...", Toast.LENGTH_SHORT).show()
            val zone = settingsManager.settings.value.scanSubtitleZone
            screenOcrManager?.triggerSingleCapture(zone)
        } else {
            Toast.makeText(this, "Buka TransLayar untuk mengizinkan Rekam Layar (Screen Capture)", Toast.LENGTH_LONG).show()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }
    }

    private fun initScreenProjection(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        screenOcrManager?.startProjection(
            resultCode = resultCode,
            data = data,
            screenDensity = metrics.densityDpi,
            width = metrics.widthPixels,
            height = metrics.heightPixels
        )
        settingsManager.updateSettings(settingsManager.settings.value.copy(isScreenCaptureActive = true))

        if (settingsManager.settings.value.isAutoScanActive) {
            screenOcrManager?.startAutoScan(
                intervalMs = 1800L,
                scanZone = settingsManager.settings.value.scanSubtitleZone
            )
        }
    }

    private fun applyStyleToOverlay(settings: OverlaySettings) {
        subtitleHudView?.let { root ->
            val cardBox = root.findViewWithTag<LinearLayout>("subtitle_card_box")
            val originalTextView = root.findViewWithTag<TextView>("original_subtitle_text")
            val translatedTextView = root.findViewWithTag<TextView>("translated_subtitle_text")

            val bgColor = try {
                Color.parseColor(settings.backgroundColorHex)
            } catch (e: Exception) {
                Color.parseColor("#E6090D16")
            }

            val txtColor = try {
                Color.parseColor(settings.textColorHex)
            } catch (e: Exception) {
                Color.parseColor("#FFEB3B")
            }

            cardBox?.let { box ->
                val bgShape = GradientDrawable().apply {
                    cornerRadius = TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP,
                        settings.boxCornerRadiusDp.toFloat(),
                        resources.displayMetrics
                    )
                    setColor(bgColor)
                    setStroke(2, Color.parseColor("#38BDF8"))
                }
                box.background = bgShape
            }

            translatedTextView?.apply {
                setTextColor(txtColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, settings.fontSizeSp.toFloat())
                if (settings.subtitleGlowOutline) {
                    setShadowLayer(8f, 0f, 0f, Color.BLACK)
                } else {
                    setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
                }
            }

            originalTextView?.visibility = if (settings.showOriginalSubtitle) View.VISIBLE else View.GONE
        }
    }

    private fun observeSettings() {
        serviceScope.launch {
            settingsManager.settings.collectLatest { settings ->
                applyStyleToOverlay(settings)

                // Voice detection control
                if (settings.isVoiceDetectionActive) {
                    startAudioDetection()
                } else {
                    stopAudioDetection()
                }

                // OCR Screen Auto-Scan control
                if (screenOcrManager?.isReady() == true) {
                    if (settings.isAutoScanActive) {
                        screenOcrManager?.startAutoScan(1800L, settings.scanSubtitleZone)
                    } else {
                        screenOcrManager?.stopAutoScan()
                    }
                }
            }
        }
    }

    private fun startAudioDetection() {
        if (audioVoiceDetector == null) {
            audioVoiceDetector = AudioVoiceDetector(this).apply {
                setOnSpeechResultListener { spokenText ->
                    processNewSubtitle(spokenText, isVoice = true)
                }
            }
        }
        audioVoiceDetector?.startListening("en-US")
    }

    private fun stopAudioDetection() {
        audioVoiceDetector?.stopListening()
        audioVoiceDetector = null
    }

    fun processNewSubtitle(text: String, isVoice: Boolean = false) {
        if (text.isBlank()) return

        serviceScope.launch {
            val settings = settingsManager.settings.value
            val translated = translationEngine.translate(
                text = text,
                sourceLang = settings.sourceLanguage,
                targetLang = settings.targetLanguage,
                isAudioMode = isVoice
            )

            // Update overlay UI
            subtitleHudView?.let { root ->
                val orig = root.findViewWithTag<TextView>("original_subtitle_text")
                val trans = root.findViewWithTag<TextView>("translated_subtitle_text")

                orig?.text = if (isVoice) "🎙️ Ucapan: $text" else "📺 Layar: $text"
                trans?.text = translated
            }

            // Save to database in background
            try {
                val db = AppDatabase.getDatabase(this@FloatingOverlayService)
                db.translationDao().insert(
                    TranslationRecord(
                        sourceText = text,
                        translatedText = translated,
                        sourceLang = settings.sourceLanguage,
                        targetLang = settings.targetLanguage,
                        mode = if (isVoice) "AUDIO" else "SCREEN"
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                settingsManager.updateSettings(settingsManager.settings.value.copy(isFloatingServiceActive = false))
                stopSelf()
            }
            ACTION_UPDATE_SUBTITLE -> {
                val subtitle = intent.getStringExtra(EXTRA_SUBTITLE_TEXT) ?: ""
                processNewSubtitle(subtitle, isVoice = false)
            }
            ACTION_TOGGLE_VOICE -> {
                val current = settingsManager.settings.value
                val newVoiceState = !current.isVoiceDetectionActive
                settingsManager.updateSettings(current.copy(isVoiceDetectionActive = newVoiceState))
            }
            ACTION_START_SCREEN_CAPTURE -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (resultCode != 0 && data != null) {
                    ScreenOcrCaptureManager.mediaProjectionResultCode = resultCode
                    ScreenOcrCaptureManager.mediaProjectionData = data
                    initScreenProjection(resultCode, data)
                }
            }
            ACTION_TRIGGER_SCAN -> {
                triggerScreenScanNow()
            }
            ACTION_TOGGLE_AUTO_SCAN -> {
                val current = settingsManager.settings.value
                settingsManager.updateSettings(current.copy(isAutoScanActive = !current.isAutoScanActive))
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopAudioDetection()
        screenOcrManager?.stopProjection()
        screenOcrManager = null
        serviceScope.cancel()
        dismissFloatingMenuPopup()

        subtitleHudView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {}
        }
        subtitleHudView = null

        floatingBubbleView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {}
        }
        floatingBubbleView = null

        super.onDestroy()
    }
}
