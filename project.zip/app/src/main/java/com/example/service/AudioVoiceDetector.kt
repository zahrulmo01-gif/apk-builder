package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class AudioVoiceDetector(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    private val _detectedSpeech = MutableStateFlow("")
    val detectedSpeech: StateFlow<String> = _detectedSpeech.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _audioRmsLevel = MutableStateFlow(0f)
    val audioRmsLevel: StateFlow<Float> = _audioRmsLevel.asStateFlow()

    private var onSpeechResultListener: ((String) -> Unit)? = null

    fun setOnSpeechResultListener(listener: (String) -> Unit) {
        this.onSpeechResultListener = listener
    }

    fun startListening(languageLocale: String = "en-US") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w("AudioVoiceDetector", "Speech recognition not available on this device")
            return
        }

        try {
            stopListening()

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isRecording.value = true
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        _audioRmsLevel.value = (rmsdB.coerceIn(0f, 10f) / 10f)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _audioRmsLevel.value = 0f
                    }

                    override fun onError(error: Int) {
                        _isRecording.value = false
                        _audioRmsLevel.value = 0f
                        Log.d("AudioVoiceDetector", "Speech error code: $error")
                        // Automatically restart if user still has voice mode active
                        if (isListening) {
                            startListening(languageLocale)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            _detectedSpeech.value = text
                            onSpeechResultListener?.invoke(text)
                        }
                        if (isListening) {
                            startListening(languageLocale)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            _detectedSpeech.value = text
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageLocale)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }

            speechRecognizer?.startListening(intent)
            isListening = true
            _isRecording.value = true
        } catch (e: Exception) {
            Log.e("AudioVoiceDetector", "Error starting speech recognition: ${e.message}")
            _isRecording.value = false
        }
    }

    fun stopListening() {
        isListening = false
        _isRecording.value = false
        _audioRmsLevel.value = 0f
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.e("AudioVoiceDetector", "Error stopping speech: ${e.message}")
        }
        speechRecognizer = null
    }

    // Manual or simulated voice feed (e.g. video audio sample)
    fun feedSimulatedVoice(phrase: String) {
        _detectedSpeech.value = phrase
        onSpeechResultListener?.invoke(phrase)
    }
}
