package com.example.service

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

class ScreenOcrCaptureManager(
    private val context: Context,
    private val onSubtitleDetected: (String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var autoScanJob: Job? = null
    private var lastRecognizedText: String = ""
    private var lastRecognizedTimestamp: Long = 0L

    companion object {
        const val TAG = "ScreenOcrCapture"
        var mediaProjectionResultCode: Int = 0
        var mediaProjectionData: Intent? = null
    }

    fun startProjection(resultCode: Int, data: Intent, screenDensity: Int, width: Int, height: Int) {
        stopProjection()
        try {
            val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            // Use slightly scaled down dimensions for high FPS and low memory
            val captureWidth = (width / 1.5).toInt().coerceAtLeast(480)
            val captureHeight = (height / 1.5).toInt().coerceAtLeast(720)

            imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "TransLayarCapture",
                captureWidth,
                captureHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
            Log.d(TAG, "VirtualDisplay created: ${captureWidth}x${captureHeight}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start MediaProjection: ${e.message}", e)
        }
    }

    fun startAutoScan(intervalMs: Long = 1800L, scanZone: String = "BOTTOM") {
        stopAutoScan()
        autoScanJob = scope.launch {
            while (isActive) {
                try {
                    captureAndProcess(scanZone)
                } catch (e: Exception) {
                    Log.e(TAG, "Auto-scan cycle error: ${e.message}")
                }
                delay(intervalMs)
            }
        }
    }

    fun stopAutoScan() {
        autoScanJob?.cancel()
        autoScanJob = null
    }

    fun triggerSingleCapture(scanZone: String = "BOTTOM") {
        scope.launch {
            captureAndProcess(scanZone)
        }
    }

    private suspend fun captureAndProcess(scanZone: String) = withContext(Dispatchers.IO) {
        val reader = imageReader ?: return@withContext
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return@withContext
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val fullBitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            fullBitmap.copyPixelsFromBuffer(buffer)

            // Crop according to subtitle zone (default BOTTOM: where movie/video subtitles appear)
            val croppedBitmap = when (scanZone) {
                "BOTTOM" -> {
                    val cropY = (fullBitmap.height * 0.58f).toInt().coerceAtLeast(0)
                    val cropHeight = (fullBitmap.height * 0.38f).toInt().coerceAtMost(fullBitmap.height - cropY)
                    val cropX = (fullBitmap.width * 0.04f).toInt().coerceAtLeast(0)
                    val cropWidth = (fullBitmap.width * 0.92f).toInt().coerceAtMost(fullBitmap.width - cropX)
                    Bitmap.createBitmap(fullBitmap, cropX, cropY, cropWidth, cropHeight)
                }
                "MIDDLE" -> {
                    val cropY = (fullBitmap.height * 0.30f).toInt().coerceAtLeast(0)
                    val cropHeight = (fullBitmap.height * 0.45f).toInt().coerceAtMost(fullBitmap.height - cropY)
                    val cropX = (fullBitmap.width * 0.05f).toInt().coerceAtLeast(0)
                    val cropWidth = (fullBitmap.width * 0.90f).toInt().coerceAtMost(fullBitmap.width - cropX)
                    Bitmap.createBitmap(fullBitmap, cropX, cropY, cropWidth, cropHeight)
                }
                else -> fullBitmap
            }

            val inputImage = InputImage.fromBitmap(croppedBitmap, 0)
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val rawText = visionText.text
                    val cleaned = cleanSubtitleCandidate(rawText)
                    if (cleaned.isNotBlank()) {
                        val now = System.currentTimeMillis()
                        // Avoid spamming if identical text was detected within 3 seconds
                        if (cleaned != lastRecognizedText || (now - lastRecognizedTimestamp) > 4000) {
                            lastRecognizedText = cleaned
                            lastRecognizedTimestamp = now
                            onSubtitleDetected(cleaned)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "OCR recognition error: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error acquiring or processing screen image: ${e.message}")
        } finally {
            try {
                image?.close()
            } catch (e: Exception) {}
        }
    }

    private fun cleanSubtitleCandidate(text: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.length > 2 }
        val filteredLines = lines.filter { line ->
            // Filter out timecode (e.g. 1:35 / 16:34) and pure numbers
            !line.matches(Regex("^[0-9:\\s/.-]+$")) &&
            !line.startsWith("http", ignoreCase = true) &&
            !line.equals("translayar", ignoreCase = true) &&
            !line.contains("English Subtitle", ignoreCase = true)
        }

        // Join lines as one subtitle sentence
        val joined = filteredLines.joinToString(" ")
            .replace(Regex("\\s+"), " ")
            .trim()

        return if (joined.length >= 3) joined else ""
    }

    fun isReady(): Boolean = mediaProjection != null && imageReader != null

    fun stopProjection() {
        stopAutoScan()
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {}
        imageReader = null

        try {
            mediaProjection?.stop()
        } catch (e: Exception) {}
        mediaProjection = null
    }
}
